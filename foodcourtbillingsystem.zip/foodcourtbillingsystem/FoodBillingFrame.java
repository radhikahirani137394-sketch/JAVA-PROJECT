import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.PrinterException;
import java.sql.*;
import java.util.ArrayList;

public class FoodBillingFrame extends JFrame {

    // PASTEL PINK + PASTEL PURPLE
    Color backgroundColor = new Color(252, 240, 248);
    Color pastelPink = new Color(225, 170, 205);
    Color pastelPurple = new Color(170, 150, 205);
    Color darkPurple = new Color(105, 85, 130);
    Color textColor = new Color(75, 65, 80);

    JComboBox<String> customerCombo;
    JComboBox<String> foodCombo;

    JTextField txtQuantity;
    JTextField txtDiscount;
    JTextField txtGST;

    JLabel lblSubtotal;
    JLabel lblGrandTotal;

    JTable cartTable;
    DefaultTableModel cartModel;

    ArrayList<Integer> foodIds = new ArrayList<>();

    public FoodBillingFrame() {

        setTitle("Food Court Billing System - Billing");

        setSize(1000, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel =
                new JPanel(new BorderLayout(15, 15));

        mainPanel.setBackground(backgroundColor);

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        JLabel title =
                new JLabel(
                        "FOOD COURT BILLING",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font("Arial", Font.BOLD, 25)
        );

        title.setForeground(darkPurple);

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // =========================
        // SELECTION PANEL
        // =========================

        JPanel selectionPanel =
                new JPanel(
                        new GridLayout(2, 4, 10, 10)
                );

        selectionPanel.setBackground(backgroundColor);

        customerCombo = new JComboBox<>();

        foodCombo = new JComboBox<>();

        txtQuantity = new JTextField("1");

        JButton addButton =
                new JButton("Add to Cart");

        selectionPanel.add(
                createLabel("Customer:")
        );

        selectionPanel.add(customerCombo);

        selectionPanel.add(
                createLabel("Food Item:")
        );

        selectionPanel.add(foodCombo);

        selectionPanel.add(
                createLabel("Quantity:")
        );

        selectionPanel.add(txtQuantity);

        selectionPanel.add(new JLabel(""));

        selectionPanel.add(addButton);

        styleButton(addButton);

        // =========================
        // CART TABLE
        // =========================

        cartModel =
                new DefaultTableModel(
                        new Object[]{
                                "Food ID",
                                "Food Item",
                                "Price",
                                "Quantity",
                                "Amount"
                        }, 0
                );

        cartTable =
                new JTable(cartModel);

        cartTable.setRowHeight(25);

        cartTable.getTableHeader()
                .setBackground(pastelPurple);

        cartTable.getTableHeader()
                .setForeground(Color.WHITE);

        cartTable.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        JScrollPane scrollPane =
                new JScrollPane(cartTable);

        // =========================
        // CART BUTTONS
        // =========================

        JPanel cartButtonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT
                        )
                );

        cartButtonPanel.setBackground(backgroundColor);

        JButton removeButton =
                new JButton("Remove Selected");

        JButton clearCartButton =
                new JButton("Clear Cart");

        styleButton(removeButton);
        styleButton(clearCartButton);

        cartButtonPanel.add(removeButton);
        cartButtonPanel.add(clearCartButton);

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        centerPanel.setBackground(backgroundColor);

        centerPanel.add(
                selectionPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        centerPanel.add(
                cartButtonPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        // =========================
        // TOTAL PANEL
        // =========================

        JPanel totalPanel =
                new JPanel(
                        new GridLayout(4, 2, 10, 10)
                );

        totalPanel.setBackground(backgroundColor);

        lblSubtotal =
                new JLabel("₹ 0.00");

        txtDiscount =
                new JTextField("0");

        txtGST =
                new JTextField("5");

        lblGrandTotal =
                new JLabel("₹ 0.00");

        totalPanel.add(
                createLabel("Subtotal:")
        );

        totalPanel.add(lblSubtotal);

        totalPanel.add(
                createLabel("Discount (%):")
        );

        totalPanel.add(txtDiscount);

        totalPanel.add(
                createLabel("GST (%):")
        );

        totalPanel.add(txtGST);

        totalPanel.add(
                createLabel("Grand Total:")
        );

        lblGrandTotal.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        lblGrandTotal.setForeground(darkPurple);

        totalPanel.add(lblGrandTotal);

        // =========================
        // BOTTOM BUTTONS
        // =========================

        JPanel bottomPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        bottomPanel.setBackground(backgroundColor);

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.RIGHT
                        )
                );

        buttonPanel.setBackground(backgroundColor);

        JButton calculateButton =
                new JButton("Calculate");

        JButton saveButton =
                new JButton("Save Bill");

        JButton printButton =
                new JButton("Print Bill");

        JButton mainMenuButton =
                new JButton("← Main Menu");

        styleButton(calculateButton);
        styleButton(saveButton);
        styleButton(printButton);
        styleButton(mainMenuButton);

        buttonPanel.add(calculateButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(printButton);
        buttonPanel.add(mainMenuButton);

        bottomPanel.add(
                totalPanel,
                BorderLayout.CENTER
        );

        bottomPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // =========================
        // LOAD DATA
        // =========================

        loadCustomers();
        loadFoodItems();

        // =========================
        // ACTIONS
        // =========================

        addButton.addActionListener(
                e -> addToCart()
        );

        removeButton.addActionListener(
                e -> removeSelectedItem()
        );

        clearCartButton.addActionListener(
                e -> clearCart()
        );

        calculateButton.addActionListener(
                e -> calculateTotal()
        );

        saveButton.addActionListener(
                e -> saveBill()
        );

        printButton.addActionListener(
                e -> printBill()
        );

        mainMenuButton.addActionListener(e -> {

            dispose();

            MainFrame frame =
                    new MainFrame();

            frame.setVisible(true);
        });
    }

    // =========================
    // LABEL
    // =========================

    private JLabel createLabel(String text) {

        JLabel label =
                new JLabel(text);

        label.setForeground(textColor);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        return label;
    }

    // =========================
    // BUTTON STYLE
    // =========================

    private void styleButton(JButton button) {

        button.setBackground(pastelPurple);

        button.setForeground(Color.WHITE);

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        button.setFocusPainted(false);
    }

    // =========================
    // LOAD CUSTOMERS
    // =========================

    private void loadCustomers() {

        customerCombo.removeAllItems();

        String sql =
                "SELECT CUSTOMER_ID, CUSTOMER_NAME " +
                "FROM CUSTOMERS " +
                "ORDER BY CUSTOMER_NAME";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                customerCombo.addItem(
                        rs.getInt("CUSTOMER_ID")
                                + " - "
                                + rs.getString(
                                        "CUSTOMER_NAME"
                                )
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Customer loading error:\n"
                            + ex.getMessage()
            );
        }
    }

    // =========================
    // LOAD FOOD ITEMS
    // =========================

    private void loadFoodItems() {

        foodCombo.removeAllItems();

        foodIds.clear();

        String sql =
                "SELECT FOOD_ID, FOOD_NAME, PRICE, " +
                "STOCK_QUANTITY " +
                "FROM FOOD_ITEMS " +
                "WHERE STOCK_QUANTITY > 0 " +
                "AND (STATUS IS NULL OR " +
                "UPPER(STATUS) = 'AVAILABLE') " +
                "ORDER BY FOOD_NAME";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                int id =
                        rs.getInt("FOOD_ID");

                String name =
                        rs.getString("FOOD_NAME");

                double price =
                        rs.getDouble("PRICE");

                int stock =
                        rs.getInt("STOCK_QUANTITY");

                foodIds.add(id);

                foodCombo.addItem(
                        name
                                + " | ₹"
                                + price
                                + " | Stock: "
                                + stock
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Food item loading error:\n"
                            + ex.getMessage()
            );
        }
    }

    // =========================
    // ADD TO CART
    // =========================

    private void addToCart() {

        if (
                foodCombo.getSelectedIndex()
                        == -1
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a food item."
            );

            return;
        }

        int quantity;

        try {

            quantity =
                    Integer.parseInt(
                            txtQuantity
                                    .getText()
                                    .trim()
                    );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Enter a valid quantity."
            );

            return;
        }

        if (quantity <= 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Quantity must be greater than 0."
            );

            return;
        }

        int foodId =
                foodIds.get(
                        foodCombo.getSelectedIndex()
                );

        String sql =
                "SELECT FOOD_NAME, PRICE, " +
                "STOCK_QUANTITY " +
                "FROM FOOD_ITEMS " +
                "WHERE FOOD_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setInt(1, foodId);

            ResultSet rs =
                    pst.executeQuery();

            if (rs.next()) {

                String name =
                        rs.getString("FOOD_NAME");

                double price =
                        rs.getDouble("PRICE");

                int stock =
                        rs.getInt("STOCK_QUANTITY");

                if (quantity > stock) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Only "
                                    + stock
                                    + " item(s) available."
                    );

                    return;
                }

                double amount =
                        price * quantity;

                cartModel.addRow(
                        new Object[]{
                                foodId,
                                name,
                                price,
                                quantity,
                                amount
                        }
                );

                calculateTotal();
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error:\n"
                            + ex.getMessage()
            );
        }
    }

    // =========================
    // REMOVE ITEM
    // =========================

    private void removeSelectedItem() {

        int row =
                cartTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Select an item to remove."
            );

            return;
        }

        cartModel.removeRow(row);

        calculateTotal();
    }

    // =========================
    // CLEAR CART
    // =========================

    private void clearCart() {

        cartModel.setRowCount(0);

        calculateTotal();
    }

    // =========================
    // CALCULATE TOTAL
    // =========================

    private void calculateTotal() {

        double subtotal = 0;

        for (
                int i = 0;
                i < cartModel.getRowCount();
                i++
        ) {

            subtotal +=
                    Double.parseDouble(
                            cartModel
                                    .getValueAt(i, 4)
                                    .toString()
                    );
        }

        double discountPercent;
        double gstPercent;

        try {

            discountPercent =
                    Double.parseDouble(
                            txtDiscount
                                    .getText()
                                    .trim()
                    );

            gstPercent =
                    Double.parseDouble(
                            txtGST
                                    .getText()
                                    .trim()
                    );

        } catch (NumberFormatException ex) {

            discountPercent = 0;
            gstPercent = 0;
        }

        double discount =
                subtotal
                        * discountPercent
                        / 100;

        double afterDiscount =
                subtotal - discount;

        double gst =
                afterDiscount
                        * gstPercent
                        / 100;

        double grandTotal =
                afterDiscount + gst;

        lblSubtotal.setText(
                String.format(
                        "₹ %.2f",
                        subtotal
                )
        );

        lblGrandTotal.setText(
                String.format(
                        "₹ %.2f",
                        grandTotal
                )
        );
    }

    // =========================
    // SAVE BILL
    // =========================

    private void saveBill() {

        if (
                customerCombo.getSelectedIndex()
                        == -1
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer."
            );

            return;
        }

        if (cartModel.getRowCount() == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please add food items to the cart."
            );

            return;
        }

        Connection con = null;

        try {

            con =
                    DBConnection.getConnection();

            con.setAutoCommit(false);

            String customerText =
                    customerCombo
                            .getSelectedItem()
                            .toString();

            int dash =
                    customerText.indexOf("-");

            int customerId =
                    Integer.parseInt(
                            customerText
                                    .substring(
                                            0,
                                            dash
                                    )
                                    .trim()
                    );

            double subtotal = 0;

            for (
                    int i = 0;
                    i < cartModel.getRowCount();
                    i++
            ) {

                subtotal +=
                        Double.parseDouble(
                                cartModel
                                        .getValueAt(i, 4)
                                        .toString()
                        );
            }

            double discountPercent =
                    Double.parseDouble(
                            txtDiscount
                                    .getText()
                                    .trim()
                    );

            double gstPercent =
                    Double.parseDouble(
                            txtGST
                                    .getText()
                                    .trim()
                    );

            double discount =
                    subtotal
                            * discountPercent
                            / 100;

            double afterDiscount =
                    subtotal - discount;

            double gst =
                    afterDiscount
                            * gstPercent
                            / 100;

            double total =
                    afterDiscount + gst;

            // PAYMENT METHOD
            String[] paymentMethods = {
                    "Cash",
                    "UPI",
                    "Card"
            };

            String paymentMethod =
                    (String) JOptionPane.showInputDialog(
                            this,
                            "Select Payment Method:",
                            "Payment",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            paymentMethods,
                            paymentMethods[0]
                    );

            if (paymentMethod == null) {

                con.rollback();

                return;
            }

            // BILL ID
            int billId;

            String billIdSql =
                    "SELECT NVL(MAX(BILL_ID), 0) + 1 " +
                    "FROM BILLS";

            try (
                    Statement st =
                            con.createStatement();

                    ResultSet rs =
                            st.executeQuery(
                                    billIdSql
                            )
            ) {

                rs.next();

                billId =
                        rs.getInt(1);
            }

            // INSERT BILL
            String billSql =
                    "INSERT INTO BILLS " +
                    "(BILL_ID, CUSTOMER_ID, BILL_DATE, " +
                    "SUBTOTAL, DISCOUNT, GST, " +
                    "TOTAL_AMOUNT, PAYMENT_METHOD, " +
                    "PAYMENT_STATUS) " +
                    "VALUES " +
                    "(?, ?, SYSDATE, ?, ?, ?, ?, ?, ?)";

            try (
                    PreparedStatement pst =
                            con.prepareStatement(
                                    billSql
                            )
            ) {

                pst.setInt(1, billId);
                pst.setInt(2, customerId);
                pst.setDouble(3, subtotal);
                pst.setDouble(4, discount);
                pst.setDouble(5, gst);
                pst.setDouble(6, total);
                pst.setString(
                        7,
                        paymentMethod
                );
                pst.setString(
                        8,
                        "PAID"
                );

                pst.executeUpdate();
            }

            // INSERT BILL ITEMS + UPDATE STOCK
            for (
                    int i = 0;
                    i < cartModel.getRowCount();
                    i++
            ) {

                int foodId =
                        Integer.parseInt(
                                cartModel
                                        .getValueAt(i, 0)
                                        .toString()
                        );

                int quantity =
                        Integer.parseInt(
                                cartModel
                                        .getValueAt(i, 3)
                                        .toString()
                        );

                double price =
                        Double.parseDouble(
                                cartModel
                                        .getValueAt(i, 2)
                                        .toString()
                        );

                double amount =
                        Double.parseDouble(
                                cartModel
                                        .getValueAt(i, 4)
                                        .toString()
                        );

                // BILL ITEM ID
                int billItemId;

                String itemIdSql =
                        "SELECT NVL(MAX(BILL_ITEM_ID), 0) + 1 " +
                        "FROM BILL_ITEMS";

                try (
                        Statement st =
                                con.createStatement();

                        ResultSet rs =
                                st.executeQuery(
                                        itemIdSql
                                )
                ) {

                    rs.next();

                    billItemId =
                            rs.getInt(1);
                }

                String itemSql =
                        "INSERT INTO BILL_ITEMS " +
                        "(BILL_ITEM_ID, BILL_ID, FOOD_ID, " +
                        "QUANTITY, PRICE, AMOUNT) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";

                try (
                        PreparedStatement pst =
                                con.prepareStatement(
                                        itemSql
                                )
                ) {

                    pst.setInt(
                            1,
                            billItemId
                    );

                    pst.setInt(
                            2,
                            billId
                    );

                    pst.setInt(
                            3,
                            foodId
                    );

                    pst.setInt(
                            4,
                            quantity
                    );

                    pst.setDouble(
                            5,
                            price
                    );

                    pst.setDouble(
                            6,
                            amount
                    );

                    pst.executeUpdate();
                }

                // UPDATE STOCK
                String stockSql =
                        "UPDATE FOOD_ITEMS " +
                        "SET STOCK_QUANTITY = " +
                        "STOCK_QUANTITY - ? " +
                        "WHERE FOOD_ID = ? " +
                        "AND STOCK_QUANTITY >= ?";

                try (
                        PreparedStatement pst =
                                con.prepareStatement(
                                        stockSql
                                )
                ) {

                    pst.setInt(1, quantity);
                    pst.setInt(2, foodId);
                    pst.setInt(3, quantity);

                    int result =
                            pst.executeUpdate();

                    if (result == 0) {

                        throw new SQLException(
                                "Not enough stock for "
                                        + cartModel
                                        .getValueAt(i, 1)
                        );
                    }
                }
            }

            // PAYMENT RECORD
            int paymentId;

            String paymentIdSql =
                    "SELECT NVL(MAX(PAYMENT_ID), 0) + 1 " +
                    "FROM PAYMENTS";

            try (
                    Statement st =
                            con.createStatement();

                    ResultSet rs =
                            st.executeQuery(
                                    paymentIdSql
                            )
            ) {

                rs.next();

                paymentId =
                        rs.getInt(1);
            }

            String paymentSql =
                    "INSERT INTO PAYMENTS " +
                    "(PAYMENT_ID, BILL_ID, " +
                    "PAYMENT_METHOD, PAYMENT_AMOUNT, " +
                    "PAYMENT_DATE, PAYMENT_STATUS) " +
                    "VALUES (?, ?, ?, ?, SYSDATE, ?)";

            try (
                    PreparedStatement pst =
                            con.prepareStatement(
                                    paymentSql
                            )
            ) {

                pst.setInt(
                        1,
                        paymentId
                );

                pst.setInt(
                        2,
                        billId
                );

                pst.setString(
                        3,
                        paymentMethod
                );

                pst.setDouble(
                        4,
                        total
                );

                pst.setString(
                        5,
                        "PAID"
                );

                pst.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(
                    this,
                    "Bill saved successfully!\n\n"
                            + "Bill ID: "
                            + billId
                            + "\nPayment: "
                            + paymentMethod
                            + "\nTotal: ₹"
                            + String.format(
                                    "%.2f",
                                    total
                            )
            );

            clearCart();

            loadFoodItems();

        } catch (Exception ex) {

            try {

                if (con != null) {
                    con.rollback();
                }

            } catch (SQLException ignored) {
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Bill could not be saved:\n"
                            + ex.getMessage()
            );

        } finally {

            try {

                if (con != null) {
                    con.close();
                }

            } catch (SQLException ignored) {
            }
        }
    }

    // =========================
    // PRINT BILL
    // =========================

    private void printBill() {

        try {

            boolean complete =
                    cartTable.print();

            if (complete) {

                JOptionPane.showMessageDialog(
                        this,
                        "Bill printed successfully."
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Printing was cancelled."
                );
            }

        } catch (PrinterException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Printing error:\n"
                            + ex.getMessage()
            );
        }
    }

    // =========================
    // MAIN
    // =========================

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            FoodBillingFrame frame =
                    new FoodBillingFrame();

            frame.setVisible(true);
        });
    }
}