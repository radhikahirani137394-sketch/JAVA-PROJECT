import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.PrinterException;
import java.sql.*;

public class FoodSalesReportFrame extends JFrame {

    Color backgroundColor = new Color(250, 240, 248);
    Color pastelPink = new Color(225, 170, 195);
    Color pastelPurple = new Color(180, 165, 215);
    Color darkPurple = new Color(100, 80, 120);
    Color textColor = new Color(70, 60, 75);

    JTable reportTable;
    DefaultTableModel tableModel;

    JLabel revenueLabel;

    public FoodSalesReportFrame() {

        setTitle("Sales Reports");
        setSize(1000, 700);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(15, 15)
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        // TITLE

        JLabel title =
                new JLabel(
                        "SALES REPORTS",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        title.setForeground(
                darkPurple
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // REPORT BUTTONS

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                8,
                                10
                        )
                );

        buttonPanel.setBackground(
                backgroundColor
        );

        JButton dailyButton =
                new JButton("Daily Sales");

        JButton monthlyButton =
                new JButton("Monthly Sales");

        JButton productButton =
                new JButton("Most Sold Items");

        JButton customerButton =
                new JButton("Customer-wise Sales");

        JButton revenueButton =
                new JButton("Total Revenue");

        JButton printButton =
                new JButton("Print Report");

        JButton mainMenuButton =
                new JButton("← Main Menu");

        JButton[] buttons = {
                dailyButton,
                monthlyButton,
                productButton,
                customerButton,
                revenueButton,
                printButton,
                mainMenuButton
        };

        for (JButton button : buttons) {

            styleButton(button);

            buttonPanel.add(button);
        }

        // TABLE

        tableModel =
                new DefaultTableModel();

        reportTable =
                new JTable(tableModel);

        reportTable.setRowHeight(25);

        reportTable
                .getTableHeader()
                .setBackground(
                        pastelPurple
                );

        reportTable
                .getTableHeader()
                .setForeground(
                        Color.WHITE
                );

        reportTable
                .getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        JScrollPane scrollPane =
                new JScrollPane(
                        reportTable
                );

        // REVENUE

        revenueLabel =
                new JLabel(
                        "Total Revenue: ₹ 0.00",
                        SwingConstants.CENTER
                );

        revenueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        revenueLabel.setForeground(
                darkPurple
        );

        // BOTTOM

        JPanel bottomPanel =
                new JPanel(
                        new BorderLayout()
                );

        bottomPanel.setBackground(
                backgroundColor
        );

        bottomPanel.add(
                revenueLabel,
                BorderLayout.NORTH
        );

        bottomPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // ACTIONS

        dailyButton.addActionListener(
                e -> dailyReport()
        );

        monthlyButton.addActionListener(
                e -> monthlyReport()
        );

        productButton.addActionListener(
                e -> productWiseReport()
        );

        customerButton.addActionListener(
                e -> customerWiseReport()
        );

        revenueButton.addActionListener(
                e -> totalRevenue()
        );

        printButton.addActionListener(
                e -> printReport()
        );

        mainMenuButton.addActionListener(e -> {

            dispose();

            MainFrame frame =
                    new MainFrame();

            frame.setVisible(true);
        });

        // Show daily report initially
        dailyReport();
    }

    private void styleButton(
            JButton button
    ) {

        button.setBackground(
                pastelPink
        );

        button.setForeground(
                darkPurple
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setFocusPainted(false);
    }

    // DAILY SALES

    private void dailyReport() {

        tableModel.setRowCount(0);

        tableModel.setColumnIdentifiers(
                new Object[]{
                        "Bill ID",
                        "Date",
                        "Customer",
                        "Total Amount",
                        "Payment Method",
                        "Payment Status"
                }
        );

        String sql =
                "SELECT b.BILL_ID, " +
                "b.BILL_DATE, " +
                "c.CUSTOMER_NAME, " +
                "b.TOTAL_AMOUNT, " +
                "b.PAYMENT_METHOD, " +
                "b.PAYMENT_STATUS " +
                "FROM BILLS b " +
                "LEFT JOIN CUSTOMERS c " +
                "ON b.CUSTOMER_ID = c.CUSTOMER_ID " +
                "WHERE TRUNC(b.BILL_DATE) = TRUNC(SYSDATE) " +
                "ORDER BY b.BILL_ID";

        executeBillReport(sql);

        updateRevenue();
    }

    // MONTHLY SALES

    private void monthlyReport() {

        tableModel.setRowCount(0);

        tableModel.setColumnIdentifiers(
                new Object[]{
                        "Bill ID",
                        "Date",
                        "Customer",
                        "Total Amount",
                        "Payment Method",
                        "Payment Status"
                }
        );

        String sql =
                "SELECT b.BILL_ID, " +
                "b.BILL_DATE, " +
                "c.CUSTOMER_NAME, " +
                "b.TOTAL_AMOUNT, " +
                "b.PAYMENT_METHOD, " +
                "b.PAYMENT_STATUS " +
                "FROM BILLS b " +
                "LEFT JOIN CUSTOMERS c " +
                "ON b.CUSTOMER_ID = c.CUSTOMER_ID " +
                "WHERE EXTRACT(MONTH FROM b.BILL_DATE) " +
                "= EXTRACT(MONTH FROM SYSDATE) " +
                "AND EXTRACT(YEAR FROM b.BILL_DATE) " +
                "= EXTRACT(YEAR FROM SYSDATE) " +
                "ORDER BY b.BILL_ID";

        executeBillReport(sql);

        updateRevenue();
    }

    // PRODUCT-WISE SALES

    private void productWiseReport() {

        tableModel.setRowCount(0);

        tableModel.setColumnIdentifiers(
                new Object[]{
                        "Food ID",
                        "Food Name",
                        "Quantity Sold",
                        "Sales Amount"
                }
        );

        String sql =
                "SELECT f.FOOD_ID, " +
                "f.FOOD_NAME, " +
                "SUM(i.QUANTITY) AS QUANTITY_SOLD, " +
                "SUM(i.AMOUNT) AS SALES_AMOUNT " +
                "FROM BILL_ITEMS i " +
                "JOIN FOOD_ITEMS f " +
                "ON i.FOOD_ID = f.FOOD_ID " +
                "GROUP BY f.FOOD_ID, " +
                "f.FOOD_NAME " +
                "ORDER BY SALES_AMOUNT DESC";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "FOOD_ID"
                                ),
                                rs.getString(
                                        "FOOD_NAME"
                                ),
                                rs.getInt(
                                        "QUANTITY_SOLD"
                                ),
                                rs.getDouble(
                                        "SALES_AMOUNT"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(ex);
        }

        updateRevenue();
    }

    // CUSTOMER-WISE SALES

    private void customerWiseReport() {

        tableModel.setRowCount(0);

        tableModel.setColumnIdentifiers(
                new Object[]{
                        "Customer ID",
                        "Customer Name",
                        "Number of Bills",
                        "Total Purchase"
                }
        );

        String sql =
                "SELECT c.CUSTOMER_ID, " +
                "c.CUSTOMER_NAME, " +
                "COUNT(b.BILL_ID) AS BILL_COUNT, " +
                "SUM(b.TOTAL_AMOUNT) AS TOTAL_PURCHASE " +
                "FROM CUSTOMERS c " +
                "JOIN BILLS b " +
                "ON c.CUSTOMER_ID = b.CUSTOMER_ID " +
                "GROUP BY c.CUSTOMER_ID, " +
                "c.CUSTOMER_NAME " +
                "ORDER BY TOTAL_PURCHASE DESC";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "CUSTOMER_ID"
                                ),
                                rs.getString(
                                        "CUSTOMER_NAME"
                                ),
                                rs.getInt(
                                        "BILL_COUNT"
                                ),
                                rs.getDouble(
                                        "TOTAL_PURCHASE"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(ex);
        }

        updateRevenue();
    }

    // TOTAL REVENUE

    private void totalRevenue() {

        tableModel.setRowCount(0);

        tableModel.setColumnIdentifiers(
                new Object[]{
                        "Description",
                        "Amount"
                }
        );

        String sql =
                "SELECT " +
                "COUNT(BILL_ID) AS TOTAL_BILLS, " +
                "NVL(SUM(TOTAL_AMOUNT), 0) " +
                "AS TOTAL_REVENUE " +
                "FROM BILLS";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            if (rs.next()) {

                int totalBills =
                        rs.getInt(
                                "TOTAL_BILLS"
                        );

                double revenue =
                        rs.getDouble(
                                "TOTAL_REVENUE"
                        );

                tableModel.addRow(
                        new Object[]{
                                "Total Number of Bills",
                                totalBills
                        }
                );

                tableModel.addRow(
                        new Object[]{
                                "Total Revenue",
                                String.format(
                                        "₹ %.2f",
                                        revenue
                                )
                        }
                );

                revenueLabel.setText(
                        String.format(
                                "Total Revenue: ₹ %.2f",
                                revenue
                        )
                );
            }

        } catch (SQLException ex) {

            showError(ex);
        }
    }

    // BILL REPORT

    private void executeBillReport(
            String sql
    ) {

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "BILL_ID"
                                ),
                                rs.getTimestamp(
                                        "BILL_DATE"
                                ),
                                rs.getString(
                                        "CUSTOMER_NAME"
                                ),
                                rs.getDouble(
                                        "TOTAL_AMOUNT"
                                ),
                                rs.getString(
                                        "PAYMENT_METHOD"
                                ),
                                rs.getString(
                                        "PAYMENT_STATUS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(ex);
        }
    }

    // UPDATE REVENUE LABEL

    private void updateRevenue() {

        String sql =
                "SELECT NVL(SUM(TOTAL_AMOUNT), 0) " +
                "AS TOTAL_REVENUE " +
                "FROM BILLS";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            if (rs.next()) {

                double revenue =
                        rs.getDouble(
                                "TOTAL_REVENUE"
                        );

                revenueLabel.setText(
                        String.format(
                                "Total Revenue: ₹ %.2f",
                                revenue
                        )
                );
            }

        } catch (SQLException ex) {

            showError(ex);
        }
    }

    // PRINT

    private void printReport() {

        try {

            boolean complete =
                    reportTable.print();

            if (complete) {

                JOptionPane.showMessageDialog(
                        this,
                        "Report printed successfully."
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Printing cancelled."
                );
            }

        } catch (PrinterException ex) {

            showError(ex);
        }
    }

    private void showError(
            Exception ex
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Error:\n"
                        + ex.getMessage()
        );
    }

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            FoodSalesReportFrame frame =
                    new FoodSalesReportFrame();

            frame.setVisible(true);
        });
    }
}