
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    // =========================
    // PASTEL PINK + PASTEL PURPLE
    // =========================

    Color backgroundColor =
            new Color(252, 240, 248);

    Color pastelPink =
            new Color(225, 170, 205);

    Color pastelPurple =
            new Color(170, 150, 205);

    Color darkPurple =
            new Color(105, 85, 130);

    Color textColor =
            new Color(75, 65, 80);

    public MainFrame() {

        setTitle(
                "Food Court Billing System"
        );

        setSize(900, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        // =========================
        // MAIN PANEL
        // =========================

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                20, 20
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        30, 40, 30, 40
                )
        );

        // =========================
        // HEADER
        // =========================

        JPanel headerPanel =
                new JPanel(
                        new BorderLayout()
                );

        headerPanel.setBackground(
                backgroundColor
        );

        JLabel title =
                new JLabel(
                        "FOOD COURT BILLING SYSTEM",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        title.setForeground(
                darkPurple
        );

        JLabel subtitle =
                new JLabel(
                        "Management Dashboard",
                        SwingConstants.CENTER
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        subtitle.setForeground(
                textColor
        );

        headerPanel.add(
                title,
                BorderLayout.CENTER
        );

        headerPanel.add(
                subtitle,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        // =========================
        // MODULE PANEL
        // =========================

        JPanel modulePanel =
                new JPanel(
                        new GridLayout(
                                5, 1, 15, 15
                        )
                );

        modulePanel.setBackground(
                backgroundColor
        );

        // MODULE 1
        JButton foodItemButton =
                createModuleButton(
                        "1. Food Item Management"
                );

        // MODULE 2
        JButton customerButton =
                createModuleButton(
                        "2. Customer Management"
                );

        // MODULE 3
        JButton billingButton =
                createModuleButton(
                        "3. Billing System"
                );

        // MODULE 4
        JButton paymentButton =
                createModuleButton(
                        "4. Payment Management"
                );

        // MODULE 5
        JButton reportButton =
                createModuleButton(
                        "5. Sales Reports"
                );

        modulePanel.add(
                foodItemButton
        );

        modulePanel.add(
                customerButton
        );

        modulePanel.add(
                billingButton
        );

        modulePanel.add(
                paymentButton
        );

        modulePanel.add(
                reportButton
        );

        mainPanel.add(
                modulePanel,
                BorderLayout.CENTER
        );

        // =========================
        // FOOTER
        // =========================

        JLabel footer =
                new JLabel(
                        "Food Court Management System",
                        SwingConstants.CENTER
                );

        footer.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        footer.setForeground(
                textColor
        );

        mainPanel.add(
                footer,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // =========================
        // ACTIONS
        // =========================

        foodItemButton.addActionListener(
                e -> {

                    new FoodItemFrame()
                            .setVisible(true);

                    dispose();
                }
        );

        customerButton.addActionListener(
                e -> {

                    new FoodCustomerFrame()
                            .setVisible(true);

                    dispose();
                }
        );

        billingButton.addActionListener(
                e -> {

                    new FoodBillingFrame()
                            .setVisible(true);

                    dispose();
                }
        );

        paymentButton.addActionListener(
                e -> {

                    new PaymentFrame()
                            .setVisible(true);

                    dispose();
                }
        );

        reportButton.addActionListener(
                e -> {

                    new FoodSalesReportFrame()
                            .setVisible(true);

                    dispose();
                }
        );
    }

    // =========================
    // MODULE BUTTON STYLE
    // =========================

    private JButton createModuleButton(
            String text
    ) {

        JButton button =
                new JButton(text);

        button.setBackground(
                pastelPurple
        );

        button.setForeground(
                Color.WHITE
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                pastelPink,
                                2
                        ),
                        BorderFactory.createEmptyBorder(
                                12, 20, 12, 20
                        )
                )
        );

        return button;
    }

    // =========================
    // MAIN
    // =========================

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            MainFrame frame =
                    new MainFrame();

            frame.setVisible(true);
        });
    }
}

