import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class PaymentFrame extends JFrame {

    Color backgroundColor = new Color(250, 240, 248);
    Color pastelPink = new Color(225, 170, 195);
    Color pastelPurple = new Color(180, 165, 215);
    Color darkPurple = new Color(100, 80, 120);
    Color textColor = new Color(70, 60, 75);

    JTextField txtBillId;
    JTextField txtAmount;

    JComboBox<String> paymentMethodCombo;
    JComboBox<String> statusCombo;

    JTable paymentTable;
    DefaultTableModel tableModel;

    public PaymentFrame() {

        setTitle("Payment Management");
        setSize(950, 650);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(15, 15)
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        // TITLE

        JLabel title =
                new JLabel(
                        "PAYMENT MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        title.setForeground(
                darkPurple
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // FORM

        JPanel formPanel =
                new JPanel(
                        new GridLayout(
                                2, 4, 10, 10
                        )
                );

        formPanel.setBackground(
                backgroundColor
        );

        txtBillId =
                new JTextField();

        txtAmount =
                new JTextField();

        paymentMethodCombo =
                new JComboBox<>(
                        new String[]{
                                "Cash",
                                "UPI",
                                "Card"
                        }
                );

        statusCombo =
                new JComboBox<>(
                        new String[]{
                                "PAID",
                                "PENDING"
                        }
                );

        formPanel.add(
                createLabel("Bill ID:")
        );

        formPanel.add(txtBillId);

        formPanel.add(
                createLabel("Payment Amount:")
        );

        formPanel.add(txtAmount);

        formPanel.add(
                createLabel("Payment Method:")
        );

        formPanel.add(
                paymentMethodCombo
        );

        formPanel.add(
                createLabel("Payment Status:")
        );

        formPanel.add(
                statusCombo
        );

        // BUTTONS

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                12,
                                10
                        )
                );

        buttonPanel.setBackground(
                backgroundColor
        );

        JButton saveButton =
                new JButton("Save Payment");

        JButton refreshButton =
                new JButton("Refresh");

        JButton clearButton =
                new JButton("Clear");

        JButton mainMenuButton =
                new JButton("← Main Menu");

        JButton[] buttons = {
                saveButton,
                refreshButton,
                clearButton,
                mainMenuButton
        };

        for (JButton button : buttons) {

            styleButton(button);

            buttonPanel.add(button);
        }

        JPanel topPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        topPanel.setBackground(
                backgroundColor
        );

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        // TABLE

        tableModel =
                new DefaultTableModel(
                        new Object[]{
                                "Payment ID",
                                "Bill ID",
                                "Payment Method",
                                "Amount",
                                "Payment Date",
                                "Status"
                        }, 0
                );

        paymentTable =
                new JTable(tableModel);

        paymentTable.setRowHeight(25);

        paymentTable
                .getTableHeader()
                .setBackground(
                        pastelPurple
                );

        paymentTable
                .getTableHeader()
                .setForeground(
                        Color.WHITE
                );

        paymentTable
                .getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        JScrollPane scrollPane =
                new JScrollPane(
                        paymentTable
                );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        centerPanel.setBackground(
                backgroundColor
        );

        centerPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        add(mainPanel);

        // ACTIONS

        saveButton.addActionListener(
                e -> savePayment()
        );

        refreshButton.addActionListener(
                e -> loadPayments()
        );

        clearButton.addActionListener(
                e -> clearFields()
        );

        mainMenuButton.addActionListener(e -> {

            dispose();

            MainFrame frame =
                    new MainFrame();

            frame.setVisible(true);
        });

        loadPayments();
    }

    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                textColor
        );

        return label;
    }

    private void styleButton(
            JButton button
    ) {

        button.setBackground(
                pastelPink
        );

        button.setForeground(
                darkPurple
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setFocusPainted(false);
    }

    // LOAD PAYMENTS

    private void loadPayments() {

        tableModel.setRowCount(0);

        String sql =
                "SELECT PAYMENT_ID, BILL_ID, " +
                "PAYMENT_METHOD, PAYMENT_AMOUNT, " +
                "PAYMENT_DATE, PAYMENT_STATUS " +
                "FROM PAYMENTS " +
                "ORDER BY PAYMENT_ID DESC";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "PAYMENT_ID"
                                ),
                                rs.getInt(
                                        "BILL_ID"
                                ),
                                rs.getString(
                                        "PAYMENT_METHOD"
                                ),
                                rs.getDouble(
                                        "PAYMENT_AMOUNT"
                                ),
                                rs.getTimestamp(
                                        "PAYMENT_DATE"
                                ),
                                rs.getString(
                                        "PAYMENT_STATUS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Error loading payments:\n"
                            + ex.getMessage()
            );
        }
    }

    // SAVE PAYMENT

    private void savePayment() {

        if (txtBillId.getText().trim().isEmpty()
                || txtAmount.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Bill ID and Payment Amount are required."
            );

            return;
        }

        int billId;

        double amount;

        try {

            billId =
                    Integer.parseInt(
                            txtBillId
                                    .getText()
                                    .trim()
                    );

            amount =
                    Double.parseDouble(
                            txtAmount
                                    .getText()
                                    .trim()
                    );

            if (amount <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Payment amount must be greater than 0."
                );

                return;
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Enter a valid Bill ID and payment amount."
            );

            return;
        }

        // Check whether bill exists

        String billCheckSql =
                "SELECT BILL_ID FROM BILLS " +
                "WHERE BILL_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement check =
                        con.prepareStatement(
                                billCheckSql
                        )
        ) {

            check.setInt(
                    1,
                    billId
            );

            ResultSet rs =
                    check.executeQuery();

            if (!rs.next()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Bill ID does not exist."
                );

                return;
            }

        } catch (SQLException ex) {

            showError(
                    "Error checking bill:\n"
                            + ex.getMessage()
            );

            return;
        }

        String sql =
                "INSERT INTO PAYMENTS " +
                "(PAYMENT_ID, BILL_ID, " +
                "PAYMENT_METHOD, PAYMENT_AMOUNT, " +
                "PAYMENT_DATE, PAYMENT_STATUS) " +
                "VALUES " +
                "(PAYMENT_SEQ.NEXTVAL, ?, ?, ?, " +
                "SYSDATE, ?)";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setInt(
                    1,
                    billId
            );

            pst.setString(
                    2,
                    paymentMethodCombo
                            .getSelectedItem()
                            .toString()
            );

            pst.setDouble(
                    3,
                    amount
            );

            pst.setString(
                    4,
                    statusCombo
                            .getSelectedItem()
                            .toString()
            );

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Payment saved successfully!"
            );

            clearFields();

            loadPayments();

        } catch (SQLException ex) {

            showError(
                    "Error saving payment:\n"
                            + ex.getMessage()
            );
        }
    }

    // CLEAR

    private void clearFields() {

        txtBillId.setText("");
        txtAmount.setText("");

        paymentMethodCombo.setSelectedIndex(0);

        statusCombo.setSelectedIndex(0);
    }

    private void showError(
            String message
    ) {

        JOptionPane.showMessageDialog(
                this,
                message
        );
    }

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            PaymentFrame frame =
                    new PaymentFrame();

            frame.setVisible(true);
        });
    }
}