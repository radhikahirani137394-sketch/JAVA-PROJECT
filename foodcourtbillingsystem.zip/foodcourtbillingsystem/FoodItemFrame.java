import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class FoodItemFrame extends JFrame {

    // Pastel Pink + Pastel Purple
    Color backgroundColor = new Color(253, 242, 248);
    Color pastelPurple = new Color(190, 170, 215);
    Color darkPurple = new Color(105, 80, 125);
    Color textColor = new Color(70, 60, 75);

    JTextField txtFoodId;
    JTextField txtFoodName;
    JTextField txtPrice;
    JTextField txtStock;
    JTextField txtSearch;

    JComboBox<String> categoryCombo;
    JComboBox<String> statusCombo;

    JTable foodTable;
    DefaultTableModel tableModel;

    public FoodItemFrame() {

        setTitle("Food Item Management");

        setSize(1050, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(15, 15)
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 25, 20, 25
                )
        );

        // TITLE
        JLabel title =
                new JLabel(
                        "FOOD ITEM MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26
                )
        );

        title.setForeground(
                darkPurple
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // FORM
        JPanel formPanel =
                new JPanel(
                        new GridLayout(
                                3, 4, 10, 10
                        )
                );

        formPanel.setBackground(
                backgroundColor
        );

        txtFoodId =
                new JTextField();

        txtFoodId.setEditable(false);

        txtFoodName =
                new JTextField();

        txtPrice =
                new JTextField();

        txtStock =
                new JTextField();

        categoryCombo =
                new JComboBox<>();

        statusCombo =
                new JComboBox<>(
                        new String[]{
                                "AVAILABLE",
                                "UNAVAILABLE"
                        }
                );

        formPanel.add(
                createLabel("Food ID:")
        );

        formPanel.add(txtFoodId);

        formPanel.add(
                createLabel("Food Name:")
        );

        formPanel.add(txtFoodName);

        formPanel.add(
                createLabel("Category:")
        );

        formPanel.add(categoryCombo);

        formPanel.add(
                createLabel("Price:")
        );

        formPanel.add(txtPrice);

        formPanel.add(
                createLabel("Stock Quantity:")
        );

        formPanel.add(txtStock);

        formPanel.add(
                createLabel("Status:")
        );

        formPanel.add(statusCombo);

        // TABLE
        tableModel =
                new DefaultTableModel(
                        new Object[]{
                                "Food ID",
                                "Food Name",
                                "Category",
                                "Price",
                                "Stock",
                                "Status"
                        },
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {
                        return false;
                    }
                };

        foodTable =
                new JTable(tableModel);

        foodTable.setRowHeight(25);

        foodTable
                .getTableHeader()
                .setBackground(
                        pastelPurple
                );

        foodTable
                .getTableHeader()
                .setForeground(
                        darkPurple
                );

        foodTable
                .getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        JScrollPane scrollPane =
                new JScrollPane(foodTable);

        // SEARCH
        JPanel searchPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT,
                                10,
                                5
                        )
                );

        searchPanel.setBackground(
                backgroundColor
        );

        searchPanel.add(
                createLabel("Search:")
        );

        txtSearch =
                new JTextField(20);

        searchPanel.add(txtSearch);

        JButton searchButton =
                createButton("Search");

        JButton refreshButton =
                createButton("Refresh");

        searchPanel.add(searchButton);
        searchPanel.add(refreshButton);

        // TOP CENTER
        JPanel topPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        topPanel.setBackground(
                backgroundColor
        );

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                searchPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        // BUTTONS
        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );

        buttonPanel.setBackground(
                backgroundColor
        );

        JButton addButton =
                createButton("Add Food Item");

        JButton updateButton =
                createButton("Update");

        JButton deleteButton =
                createButton("Delete");

        JButton clearButton =
                createButton("Clear");

        JButton categoryButton =
                createButton("Category Management");

        JButton mainMenuButton =
                createButton("← Main Menu");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(categoryButton);
        buttonPanel.add(mainMenuButton);

        mainPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        // LOAD DATA
        loadCategories();

        loadFoodItems();

        // ACTIONS

        addButton.addActionListener(
                e -> addFoodItem()
        );

        updateButton.addActionListener(
                e -> updateFoodItem()
        );

        deleteButton.addActionListener(
                e -> deleteFoodItem()
        );

        clearButton.addActionListener(
                e -> clearFields()
        );

        searchButton.addActionListener(
                e -> searchFoodItems()
        );

        refreshButton.addActionListener(
                e -> {
                    txtSearch.setText("");
                    loadFoodItems();
                }
        );

        categoryButton.addActionListener(
                e -> categoryManagement()
        );

        foodTable.getSelectionModel()
                .addListSelectionListener(
                        e -> loadSelectedFood()
                );

        mainMenuButton.addActionListener(
                e -> openMainMenu()
        );
    }

    // LABEL
    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                textColor
        );

        return label;
    }

    // BUTTON
    private JButton createButton(
            String text
    ) {

        JButton button =
                new JButton(text);

        button.setBackground(
                pastelPurple
        );

        button.setForeground(
                darkPurple
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setFocusPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }

    // LOAD CATEGORIES
    private void loadCategories() {

        categoryCombo.removeAllItems();

        String sql =
                "SELECT CATEGORY_ID, CATEGORY_NAME " +
                "FROM CATEGORIES " +
                "ORDER BY CATEGORY_NAME";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                categoryCombo.addItem(
                        rs.getInt("CATEGORY_ID")
                                + " - "
                                + rs.getString(
                                        "CATEGORY_NAME"
                                )
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Category loading error:\n"
                            + ex.getMessage()
            );
        }
    }

    // LOAD FOOD ITEMS
    private void loadFoodItems() {

        tableModel.setRowCount(0);

        String sql =
                "SELECT f.FOOD_ID, " +
                "f.FOOD_NAME, " +
                "c.CATEGORY_NAME, " +
                "f.PRICE, " +
                "f.STOCK_QUANTITY, " +
                "f.STATUS " +
                "FROM FOOD_ITEMS f " +
                "LEFT JOIN CATEGORIES c " +
                "ON f.CATEGORY_ID = c.CATEGORY_ID " +
                "ORDER BY f.FOOD_ID";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "FOOD_ID"
                                ),
                                rs.getString(
                                        "FOOD_NAME"
                                ),
                                rs.getString(
                                        "CATEGORY_NAME"
                                ),
                                rs.getDouble(
                                        "PRICE"
                                ),
                                rs.getInt(
                                        "STOCK_QUANTITY"
                                ),
                                rs.getString(
                                        "STATUS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Food loading error:\n"
                            + ex.getMessage()
            );
        }
    }

    // GET CATEGORY ID
    private int getCategoryId() {

        if (
                categoryCombo.getSelectedIndex()
                        == -1
        ) {
            return -1;
        }

        String selected =
                categoryCombo
                        .getSelectedItem()
                        .toString();

        int dash =
                selected.indexOf("-");

        return Integer.parseInt(
                selected
                        .substring(
                                0,
                                dash
                        )
                        .trim()
        );
    }

    // ADD
    private void addFoodItem() {

        String name =
                txtFoodName
                        .getText()
                        .trim();

        if (name.isEmpty()) {

            showError(
                    "Please enter food name."
            );

            return;
        }

        int categoryId =
                getCategoryId();

        if (categoryId == -1) {

            showError(
                    "Please select a category."
            );

            return;
        }

        double price;
        int stock;

        try {

            price =
                    Double.parseDouble(
                            txtPrice
                                    .getText()
                                    .trim()
                    );

            stock =
                    Integer.parseInt(
                            txtStock
                                    .getText()
                                    .trim()
                    );

            if (price < 0 || stock < 0) {
                throw new NumberFormatException();
            }

        } catch (NumberFormatException ex) {

            showError(
                    "Enter valid price and stock."
            );

            return;
        }

        String sql =
                "INSERT INTO FOOD_ITEMS " +
                "(FOOD_ID, FOOD_NAME, " +
                "CATEGORY_ID, PRICE, " +
                "STOCK_QUANTITY, STATUS) " +
                "VALUES " +
                "((SELECT NVL(MAX(FOOD_ID),0)+1 " +
                "FROM FOOD_ITEMS), ?, ?, ?, ?, ?)";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setString(1, name);
            pst.setInt(2, categoryId);
            pst.setDouble(3, price);
            pst.setInt(4, stock);

            pst.setString(
                    5,
                    statusCombo
                            .getSelectedItem()
                            .toString()
            );

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Food item added successfully!"
            );

            loadFoodItems();

            clearFields();

        } catch (SQLException ex) {

            showError(
                    "Error adding food item:\n"
                            + ex.getMessage()
            );
        }
    }

    // UPDATE
    private void updateFoodItem() {

        if (txtFoodId.getText().trim().isEmpty()) {

            showError(
                    "Select a food item first."
            );

            return;
        }

        String name =
                txtFoodName
                        .getText()
                        .trim();

        int categoryId =
                getCategoryId();

        double price;
        int stock;

        try {

            price =
                    Double.parseDouble(
                            txtPrice
                                    .getText()
                                    .trim()
                    );

            stock =
                    Integer.parseInt(
                            txtStock
                                    .getText()
                                    .trim()
                    );

        } catch (NumberFormatException ex) {

            showError(
                    "Enter valid price and stock."
            );

            return;
        }

        int foodId =
                Integer.parseInt(
                        txtFoodId
                                .getText()
                                .trim()
                );

        String sql =
                "UPDATE FOOD_ITEMS " +
                "SET FOOD_NAME = ?, " +
                "CATEGORY_ID = ?, " +
                "PRICE = ?, " +
                "STOCK_QUANTITY = ?, " +
                "STATUS = ? " +
                "WHERE FOOD_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setString(1, name);
            pst.setInt(2, categoryId);
            pst.setDouble(3, price);
            pst.setInt(4, stock);

            pst.setString(
                    5,
                    statusCombo
                            .getSelectedItem()
                            .toString()
            );

            pst.setInt(6, foodId);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Food item updated successfully!"
            );

            loadFoodItems();

            clearFields();

        } catch (SQLException ex) {

            showError(
                    "Update error:\n"
                            + ex.getMessage()
            );
        }
    }

    // DELETE
    private void deleteFoodItem() {

        if (txtFoodId.getText().trim().isEmpty()) {

            showError(
                    "Select a food item first."
            );

            return;
        }

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this food item?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );

        if (
                confirm !=
                JOptionPane.YES_OPTION
        ) {
            return;
        }

        int foodId =
                Integer.parseInt(
                        txtFoodId
                                .getText()
                                .trim()
                );

        String sql =
                "DELETE FROM FOOD_ITEMS " +
                "WHERE FOOD_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setInt(1, foodId);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Food item deleted successfully!"
            );

            loadFoodItems();

            clearFields();

        } catch (SQLException ex) {

            showError(
                    "Delete error:\n"
                            + ex.getMessage()
            );
        }
    }

    // SEARCH
    private void searchFoodItems() {

        String search =
                txtSearch
                        .getText()
                        .trim();

        if (search.isEmpty()) {

            loadFoodItems();

            return;
        }

        tableModel.setRowCount(0);

        String sql =
                "SELECT f.FOOD_ID, " +
                "f.FOOD_NAME, " +
                "c.CATEGORY_NAME, " +
                "f.PRICE, " +
                "f.STOCK_QUANTITY, " +
                "f.STATUS " +
                "FROM FOOD_ITEMS f " +
                "LEFT JOIN CATEGORIES c " +
                "ON f.CATEGORY_ID = c.CATEGORY_ID " +
                "WHERE LOWER(f.FOOD_NAME) " +
                "LIKE LOWER(?) " +
                "OR LOWER(c.CATEGORY_NAME) " +
                "LIKE LOWER(?) " +
                "ORDER BY f.FOOD_ID";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "FOOD_ID"
                                ),
                                rs.getString(
                                        "FOOD_NAME"
                                ),
                                rs.getString(
                                        "CATEGORY_NAME"
                                ),
                                rs.getDouble(
                                        "PRICE"
                                ),
                                rs.getInt(
                                        "STOCK_QUANTITY"
                                ),
                                rs.getString(
                                        "STATUS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Search error:\n"
                            + ex.getMessage()
            );
        }
    }

    // SELECT TABLE ROW
    private void loadSelectedFood() {

        int row =
                foodTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        txtFoodId.setText(
                foodTable
                        .getValueAt(row, 0)
                        .toString()
        );

        txtFoodName.setText(
                foodTable
                        .getValueAt(row, 1)
                        .toString()
        );

        txtPrice.setText(
                foodTable
                        .getValueAt(row, 3)
                        .toString()
        );

        txtStock.setText(
                foodTable
                        .getValueAt(row, 4)
                        .toString()
        );

        String status =
                foodTable
                        .getValueAt(row, 5)
                        .toString();

        statusCombo.setSelectedItem(status);

        String category =
                foodTable
                        .getValueAt(row, 2)
                        .toString();

        for (
                int i = 0;
                i < categoryCombo
                        .getItemCount();
                i++
        ) {

            if (
                    categoryCombo
                            .getItemAt(i)
                            .contains(
                                    "- " + category
                            )
            ) {

                categoryCombo
                        .setSelectedIndex(i);

                break;
            }
        }
    }

    // CLEAR
    private void clearFields() {

        txtFoodId.setText("");

        txtFoodName.setText("");

        txtPrice.setText("");

        txtStock.setText("");

        if (
                categoryCombo
                        .getItemCount() > 0
        ) {
            categoryCombo
                    .setSelectedIndex(0);
        }

        statusCombo.setSelectedIndex(0);

        foodTable.clearSelection();
    }

    // CATEGORY MANAGEMENT
    private void categoryManagement() {

        JTextField categoryName =
                new JTextField();

        int result =
                JOptionPane.showConfirmDialog(
                        this,
                        categoryName,
                        "Add New Category",
                        JOptionPane.OK_CANCEL_OPTION
                );

        if (
                result !=
                JOptionPane.OK_OPTION
        ) {
            return;
        }

        String name =
                categoryName
                        .getText()
                        .trim();

        if (name.isEmpty()) {

            showError(
                    "Please enter category name."
            );

            return;
        }

        String sql =
                "INSERT INTO CATEGORIES " +
                "(CATEGORY_ID, CATEGORY_NAME) " +
                "VALUES " +
                "((SELECT NVL(MAX(CATEGORY_ID),0)+1 " +
                "FROM CATEGORIES), ?)";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setString(1, name);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Category added successfully!"
            );

            loadCategories();

        } catch (SQLException ex) {

            showError(
                    "Category error:\n"
                            + ex.getMessage()
            );
        }
    }

    // MAIN MENU
    private void openMainMenu() {

        dispose();

        MainFrame frame =
                new MainFrame();

        frame.setVisible(true);
    }

    // ERROR
    private void showError(
            String message
    ) {

        JOptionPane.showMessageDialog(
                this,
                message
        );
    }

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            FoodItemFrame frame =
                    new FoodItemFrame();

            frame.setVisible(true);
        });
    }
}