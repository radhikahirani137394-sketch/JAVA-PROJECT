import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class FoodCustomerFrame extends JFrame {

    Color backgroundColor = new Color(250, 240, 248);
    Color pastelPink = new Color(225, 170, 195);
    Color pastelPurple = new Color(180, 165, 215);
    Color darkPurple = new Color(100, 80, 120);
    Color textColor = new Color(70, 60, 75);

    JTextField txtId;
    JTextField txtName;
    JTextField txtPhone;
    JTextField txtEmail;
    JTextField txtAddress;
    JTextField txtSearch;

    JTable customerTable;
    DefaultTableModel tableModel;

    public FoodCustomerFrame() {

        setTitle("Customer Management");
        setSize(1000, 700);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(15, 15)
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        // TITLE

        JLabel title =
                new JLabel(
                        "CUSTOMER MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        title.setForeground(
                darkPurple
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // FORM

        JPanel formPanel =
                new JPanel(
                        new GridLayout(
                                3, 4, 10, 10
                        )
                );

        formPanel.setBackground(
                backgroundColor
        );

        txtId = new JTextField();
        txtName = new JTextField();
        txtPhone = new JTextField();
        txtEmail = new JTextField();
        txtAddress = new JTextField();
        txtSearch = new JTextField();

        formPanel.add(
                createLabel("Customer ID:")
        );

        formPanel.add(txtId);

        formPanel.add(
                createLabel("Customer Name:")
        );

        formPanel.add(txtName);

        formPanel.add(
                createLabel("Phone:")
        );

        formPanel.add(txtPhone);

        formPanel.add(
                createLabel("Email:")
        );

        formPanel.add(txtEmail);

        formPanel.add(
                createLabel("Address:")
        );

        formPanel.add(txtAddress);

        formPanel.add(
                createLabel("Search:")
        );

        formPanel.add(txtSearch);

        // BUTTONS

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );

        buttonPanel.setBackground(
                backgroundColor
        );

        JButton addButton =
                new JButton("Add Customer");

        JButton updateButton =
                new JButton("Update");

        JButton deleteButton =
                new JButton("Delete");

        JButton searchButton =
                new JButton("Search");

        JButton viewButton =
                new JButton("View All");

        JButton clearButton =
                new JButton("Clear");

        JButton mainMenuButton =
                new JButton("← Main Menu");

        JButton[] buttons = {
                addButton,
                updateButton,
                deleteButton,
                searchButton,
                viewButton,
                clearButton,
                mainMenuButton
        };

        for (JButton button : buttons) {
            styleButton(button);
            buttonPanel.add(button);
        }

        // TOP AREA

        JPanel topPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        topPanel.setBackground(
                backgroundColor
        );

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        // TABLE

        tableModel =
                new DefaultTableModel(
                        new Object[]{
                                "Customer ID",
                                "Customer Name",
                                "Phone",
                                "Email",
                                "Address"
                        }, 0
                );

        customerTable =
                new JTable(tableModel);

        customerTable.setRowHeight(25);

        customerTable
                .getTableHeader()
                .setBackground(
                        pastelPurple
                );

        customerTable
                .getTableHeader()
                .setForeground(
                        Color.WHITE
                );

        customerTable
                .getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        JScrollPane scrollPane =
                new JScrollPane(
                        customerTable
                );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout()
                );

        centerPanel.setBackground(
                backgroundColor
        );

        centerPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        add(mainPanel);

        // ACTIONS

        addButton.addActionListener(
                e -> addCustomer()
        );

        updateButton.addActionListener(
                e -> updateCustomer()
        );

        deleteButton.addActionListener(
                e -> deleteCustomer()
        );

        searchButton.addActionListener(
                e -> searchCustomer()
        );

        viewButton.addActionListener(
                e -> loadCustomers()
        );

        clearButton.addActionListener(
                e -> clearFields()
        );

        mainMenuButton.addActionListener(e -> {

            dispose();

            MainFrame frame =
                    new MainFrame();

            frame.setVisible(true);
        });

        customerTable.getSelectionModel()
                .addListSelectionListener(e -> {

                    int row =
                            customerTable
                                    .getSelectedRow();

                    if (row != -1) {

                        txtId.setText(
                                customerTable
                                        .getValueAt(
                                                row, 0
                                        )
                                        .toString()
                        );

                        txtName.setText(
                                customerTable
                                        .getValueAt(
                                                row, 1
                                        )
                                        .toString()
                        );

                        txtPhone.setText(
                                customerTable
                                        .getValueAt(
                                                row, 2
                                        )
                                        .toString()
                        );

                        txtEmail.setText(
                                customerTable
                                        .getValueAt(
                                                row, 3
                                        )
                                        .toString()
                        );

                        txtAddress.setText(
                                customerTable
                                        .getValueAt(
                                                row, 4
                                        )
                                        .toString()
                        );
                    }
                });

        loadCustomers();
    }

    private JLabel createLabel(
            String text
    ) {

        JLabel label =
                new JLabel(text);

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                textColor
        );

        return label;
    }

    private void styleButton(
            JButton button
    ) {

        button.setBackground(
                pastelPink
        );

        button.setForeground(
                darkPurple
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setFocusPainted(false);
    }

    // LOAD CUSTOMERS

    private void loadCustomers() {

        tableModel.setRowCount(0);

        String sql =
                "SELECT CUSTOMER_ID, CUSTOMER_NAME, " +
                "PHONE, EMAIL, ADDRESS " +
                "FROM CUSTOMERS " +
                "ORDER BY CUSTOMER_ID";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "CUSTOMER_ID"
                                ),
                                rs.getString(
                                        "CUSTOMER_NAME"
                                ),
                                rs.getString(
                                        "PHONE"
                                ),
                                rs.getString(
                                        "EMAIL"
                                ),
                                rs.getString(
                                        "ADDRESS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Error loading customers:\n"
                            + ex.getMessage()
            );
        }
    }

    // ADD CUSTOMER

    private void addCustomer() {

        if (txtId.getText().trim().isEmpty()
                || txtName.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Customer ID and Name are required."
            );

            return;
        }

        String sql =
                "INSERT INTO CUSTOMERS " +
                "(CUSTOMER_ID, CUSTOMER_NAME, " +
                "PHONE, EMAIL, ADDRESS) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setInt(
                    1,
                    Integer.parseInt(
                            txtId.getText().trim()
                    )
            );

            pst.setString(
                    2,
                    txtName.getText().trim()
            );

            pst.setString(
                    3,
                    txtPhone.getText().trim()
            );

            pst.setString(
                    4,
                    txtEmail.getText().trim()
            );

            pst.setString(
                    5,
                    txtAddress.getText().trim()
            );

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Customer added successfully!"
            );

            clearFields();
            loadCustomers();

        } catch (Exception ex) {

            showError(
                    "Error adding customer:\n"
                            + ex.getMessage()
            );
        }
    }

    // UPDATE CUSTOMER

    private void updateCustomer() {

        if (txtId.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Select a customer first."
            );

            return;
        }

        String sql =
                "UPDATE CUSTOMERS SET " +
                "CUSTOMER_NAME = ?, " +
                "PHONE = ?, " +
                "EMAIL = ?, " +
                "ADDRESS = ? " +
                "WHERE CUSTOMER_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setString(
                    1,
                    txtName.getText().trim()
            );

            pst.setString(
                    2,
                    txtPhone.getText().trim()
            );

            pst.setString(
                    3,
                    txtEmail.getText().trim()
            );

            pst.setString(
                    4,
                    txtAddress.getText().trim()
            );

            pst.setInt(
                    5,
                    Integer.parseInt(
                            txtId.getText().trim()
                    )
            );

            int result =
                    pst.executeUpdate();

            if (result > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Customer updated successfully!"
                );

                clearFields();
                loadCustomers();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Customer not found."
                );
            }

        } catch (Exception ex) {

            showError(
                    "Error updating customer:\n"
                            + ex.getMessage()
            );
        }
    }

    // DELETE CUSTOMER

    private void deleteCustomer() {

        if (txtId.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Select a customer first."
            );

            return;
        }

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this customer?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "DELETE FROM CUSTOMERS " +
                "WHERE CUSTOMER_ID = ?";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            pst.setInt(
                    1,
                    Integer.parseInt(
                            txtId.getText().trim()
                    )
            );

            int result =
                    pst.executeUpdate();

            if (result > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Customer deleted successfully!"
                );

                clearFields();
                loadCustomers();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Customer not found."
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Error deleting customer:\n"
                            + ex.getMessage()
            );
        }
    }

    // SEARCH CUSTOMER

    private void searchCustomer() {

        String search =
                txtSearch.getText().trim();

        if (search.isEmpty()) {

            loadCustomers();

            return;
        }

        tableModel.setRowCount(0);

        String sql =
                "SELECT CUSTOMER_ID, CUSTOMER_NAME, " +
                "PHONE, EMAIL, ADDRESS " +
                "FROM CUSTOMERS " +
                "WHERE LOWER(CUSTOMER_NAME) LIKE LOWER(?) " +
                "OR PHONE LIKE ? " +
                "OR LOWER(EMAIL) LIKE LOWER(?) " +
                "ORDER BY CUSTOMER_ID";

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement pst =
                        con.prepareStatement(sql)
        ) {

            String value =
                    "%" + search + "%";

            pst.setString(1, value);
            pst.setString(2, value);
            pst.setString(3, value);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                tableModel.addRow(
                        new Object[]{
                                rs.getInt(
                                        "CUSTOMER_ID"
                                ),
                                rs.getString(
                                        "CUSTOMER_NAME"
                                ),
                                rs.getString(
                                        "PHONE"
                                ),
                                rs.getString(
                                        "EMAIL"
                                ),
                                rs.getString(
                                        "ADDRESS"
                                )
                        }
                );
            }

        } catch (SQLException ex) {

            showError(
                    "Search error:\n"
                            + ex.getMessage()
            );
        }
    }

    // CLEAR

    private void clearFields() {

        txtId.setText("");
        txtName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        txtSearch.setText("");

        customerTable.clearSelection();
    }

    private void showError(
            String message
    ) {

        JOptionPane.showMessageDialog(
                this,
                message
        );
    }

    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            FoodCustomerFrame frame =
                    new FoodCustomerFrame();

            frame.setVisible(true);
        });
    }
}